// biome-ignore-all lint: generated file
/* eslint-disable */
import "workflow/internal/builtins";
import "../../../../../../node_modules/@workflow/core/dist/runtime/run.js";
import "../../../../../../node_modules/@workflow/core/dist/runtime/start.js";
import "../../../../../../workflows/hiring.js";

export const __steps_registered = true;
