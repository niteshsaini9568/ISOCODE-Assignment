// biome-ignore-all lint: generated file
/* eslint-disable */
import { __steps_registered } from './__step_registrations.js';
import { workflowEntrypoint } from 'workflow/runtime';

const workflowRouteModuleBodyStartedAt = Date.now();

// Prevent rollup from tree-shaking the steps side-effect import
void __steps_registered;

const workflowCode = `globalThis.__private_workflows = new Map();
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// workflows/hiring.js
var processNext = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//./workflows/hiring//processNext");
async function processHiring(workspace) {
  while (await processNext(workspace)) {
  }
}
__name(processHiring, "processHiring");
processHiring.workflowId = "workflow//./workflows/hiring//processHiring";
globalThis.__private_workflows.set("workflow//./workflows/hiring//processHiring", processHiring);

// node_modules/@workflow/serde/dist/index.js
var WORKFLOW_SERIALIZE = /* @__PURE__ */ Symbol.for("workflow-serialize");
var WORKFLOW_DESERIALIZE = /* @__PURE__ */ Symbol.for("workflow-deserialize");

// node_modules/@workflow/world/dist/env-config.js
var WarnedEnvValuesKey = /* @__PURE__ */ Symbol.for("@workflow/world//warnedEnvValues/v1");
var globalStore = globalThis;
var warnedEnvValues = globalStore[WarnedEnvValuesKey] ??= /* @__PURE__ */ new Set();

// node_modules/@workflow/core/dist/runtime/child-run-completion.js
var CHILD_RUN_COMPLETION_TOKEN_PREFIX = "wkf_child_run_completion:";
function safetyCheckDelayMs(index) {
  return Math.min(5 * 6e4 * 2 ** index, 6 * 60 * 6e4);
}
__name(safetyCheckDelayMs, "safetyCheckDelayMs");
function childRunCompletionToken(parentRunId) {
  return \`\${CHILD_RUN_COMPLETION_TOKEN_PREFIX}\${parentRunId}\`;
}
__name(childRunCompletionToken, "childRunCompletionToken");
var WORKFLOW_CREATE_HOOK = /* @__PURE__ */ Symbol.for("WORKFLOW_CREATE_HOOK");
var WORKFLOW_SLEEP = /* @__PURE__ */ Symbol.for("WORKFLOW_SLEEP");
var WORKFLOW_CONTEXT = /* @__PURE__ */ Symbol.for("WORKFLOW_CONTEXT");
var DISPATCHER = /* @__PURE__ */ Symbol.for("@workflow/core//childRunCompletionDispatcher");
function awaitChildRunCompletion(childRunId, parentRunId, readValue, readFinished) {
  if (!parentRunId) return void 0;
  const g = globalThis;
  const createHook = g[WORKFLOW_CREATE_HOOK];
  const sleep = g[WORKFLOW_SLEEP];
  const ctx = g[WORKFLOW_CONTEXT];
  if (typeof createHook !== "function" || typeof sleep !== "function" || ctx?.workflowRunId !== parentRunId) {
    return void 0;
  }
  let d = g[DISPATCHER];
  if (!d) {
    d = {
      waits: /* @__PURE__ */ new Map(),
      waiting: /* @__PURE__ */ new Map(),
      toCheck: [],
      wake: void 0,
      running: false,
      conflicted: false,
      safety: void 0,
      safetyIndex: 0
    };
    g[DISPATCHER] = d;
  }
  const existing = d.waits.get(childRunId);
  if (existing) return existing;
  const dispatcher = d;
  const wait = (async () => {
    if (!dispatcher.conflicted) {
      const done = new Promise((resolve) => {
        dispatcher.waiting.set(childRunId, resolve);
      });
      dispatcher.toCheck.push(childRunId);
      dispatcher.wake?.();
      if (!dispatcher.running) {
        dispatcher.running = true;
        void dispatch(dispatcher, parentRunId, createHook, sleep, readFinished);
      }
      await done;
    }
    return await readValue();
  })();
  dispatcher.waits.set(childRunId, wait);
  return wait;
}
__name(awaitChildRunCompletion, "awaitChildRunCompletion");
function release(d, runId) {
  const resolve = d.waiting.get(runId);
  if (!resolve) return;
  d.waiting.delete(runId);
  resolve();
}
__name(release, "release");
async function dispatch(d, parentRunId, createHook, sleep, readFinished) {
  const hook = createHook({
    token: childRunCompletionToken(parentRunId),
    isSystem: true
  });
  try {
    const conflict = await hook.getConflict().catch(() => true);
    if (conflict !== null) {
      d.conflicted = true;
      for (const runId of [
        ...d.waiting.keys()
      ]) release(d, runId);
      d.toCheck.length = 0;
      return;
    }
    if (d.safety === void 0) d.safetyIndex = 0;
    let nextPayload;
    while (d.waiting.size > 0) {
      if (d.toCheck.length > 0) {
        const runIds = d.toCheck.splice(0);
        for (const runId of await readFinished(runIds)) release(d, runId);
        continue;
      }
      nextPayload ??= hook.then((payload) => ({
        kind: "payload",
        payload
      }));
      if (d.safety === void 0) {
        const safety2 = sleep(safetyCheckDelayMs(d.safetyIndex));
        d.safety = safety2;
        void safety2.then(() => {
          if (d.safety === safety2) d.safety = void 0;
        });
      }
      const safety = d.safety;
      const nudge = new Promise((resolve) => {
        d.wake = () => resolve({
          kind: "nudge"
        });
      });
      const wakeup = await Promise.race([
        nextPayload,
        safety.then(() => ({
          kind: "safety"
        })),
        nudge
      ]);
      d.wake = void 0;
      if (wakeup.kind === "payload") {
        nextPayload = void 0;
        release(d, wakeup.payload.runId);
      } else if (wakeup.kind === "safety") {
        if (d.safety === safety) d.safety = void 0;
        d.safetyIndex++;
        d.toCheck.push(...d.waiting.keys());
      }
    }
  } catch {
    d.toCheck.length = 0;
    for (const runId of [
      ...d.waiting.keys()
    ]) release(d, runId);
  } finally {
    hook.dispose();
    d.running = false;
  }
}
__name(dispatch, "dispatch");

// node_modules/@workflow/core/dist/runtime/run.js
var Run = class _Run {
  static {
    __name(this, "Run");
  }
  static [WORKFLOW_SERIALIZE](instance) {
    return {
      runId: instance.runId,
      resilientStart: instance.#resilientStart,
      ...instance.#parentRunId ? {
        parentRunId: instance.#parentRunId
      } : {}
    };
  }
  static [WORKFLOW_DESERIALIZE](data) {
    return new _Run(data.runId, {
      resilientStart: data.resilientStart,
      parentRunId: data.parentRunId
    });
  }
  /**
   * The ID of the workflow run.
   */
  runId;
  /**
   * When true, run_created failed and the run may not exist yet (the
   * resilient start path will create it via run_started). pollReturnValue
   * retries on WorkflowRunNotFoundError only when this flag is set so
   * that normal runs fail fast on 404.
   * @internal
   */
  #resilientStart = false;
  /**
   * The workflow run that started this run with \`start()\` and that this run
   * resumes, through the child-run completion hook, when it finishes. Set only
   * on handles returned by such a \`start()\`. Inside that parent workflow,
   * \`returnValue\` suspends on the hook instead of polling.
   * @internal
   */
  #parentRunId;
  constructor(runId, opts) {
    this.runId = runId;
    this.#resilientStart = opts?.resilientStart ?? false;
    this.#parentRunId = opts?.parentRunId;
  }
  /**
   * The return value of the workflow run, once it completes. Rejects with
   * \`WorkflowRunFailedError\` or \`WorkflowRunCancelledError\` if the run fails
   * or is cancelled.
   *
   * Inside the workflow that started this run, the parent suspends on a system
   * hook the run resumes when it finishes, so waiting costs no compute and
   * resumes as soon as the run is done. Everywhere else (host code, steps,
   * a workflow handed another run's handle) it polls until the run finishes.
   */
  get returnValue() {
    return awaitChildRunCompletion(this.runId, this.#parentRunId, () => this.readReturnValue(), (runIds) => _Run.readFinishedRunIds(runIds)) ?? this.readReturnValue();
  }
  /**
   * The readable stream of the workflow run.
   */
  get readable() {
    return this.getReadable();
  }
  /** The writable stream of the workflow run. */
  get writable() {
    return this.getWritable();
  }
};
Run.readFinishedRunIds = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run.readFinishedRunIds");
Run.prototype["wakeUp"] = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#wakeUp");
Run.prototype["cancel"] = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#cancel");
Run.prototype["readReturnValue"] = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#readReturnValue");
Run.prototype["getReadable"] = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#getReadable");
Run.prototype["getWritable"] = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#getWritable");
var __step_Run\$exists = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#exists");
Object.defineProperty(Run.prototype, "exists", {
  get() {
    return __step_Run\$exists.call(this);
  },
  configurable: true,
  enumerable: false
});
var __step_Run\$status = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#status");
Object.defineProperty(Run.prototype, "status", {
  get() {
    return __step_Run\$status.call(this);
  },
  configurable: true,
  enumerable: false
});
var __step_Run\$workflowName = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#workflowName");
Object.defineProperty(Run.prototype, "workflowName", {
  get() {
    return __step_Run\$workflowName.call(this);
  },
  configurable: true,
  enumerable: false
});
var __step_Run\$createdAt = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#createdAt");
Object.defineProperty(Run.prototype, "createdAt", {
  get() {
    return __step_Run\$createdAt.call(this);
  },
  configurable: true,
  enumerable: false
});
var __step_Run\$startedAt = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#startedAt");
Object.defineProperty(Run.prototype, "startedAt", {
  get() {
    return __step_Run\$startedAt.call(this);
  },
  configurable: true,
  enumerable: false
});
var __step_Run\$completedAt = globalThis[/* @__PURE__ */ Symbol.for("WORKFLOW_USE_STEP")]("step//@workflow/core/runtime/run@5.4.0//Run#completedAt");
Object.defineProperty(Run.prototype, "completedAt", {
  get() {
    return __step_Run\$completedAt.call(this);
  },
  configurable: true,
  enumerable: false
});
(function(__wf_cls, __wf_id) {
  var __wf_sym = /* @__PURE__ */ Symbol.for("workflow-class-registry"), __wf_reg = globalThis[__wf_sym] || (globalThis[__wf_sym] = /* @__PURE__ */ new Map());
  __wf_reg.set(__wf_id, __wf_cls);
  if (!Object.prototype.hasOwnProperty.call(__wf_cls, "classId")) Object.defineProperty(__wf_cls, "classId", {
    value: __wf_id,
    writable: false,
    enumerable: false,
    configurable: false
  });
})(Run, "class//@workflow/core/runtime/run@5.4.0//Run");
`;

export const POST = workflowEntrypoint(workflowCode, { routeModuleBodyStartedAt: workflowRouteModuleBodyStartedAt });
export const GET = POST;
export const HEAD = POST;
export const OPTIONS = POST;